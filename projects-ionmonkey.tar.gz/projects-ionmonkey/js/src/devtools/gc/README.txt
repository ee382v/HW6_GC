Usage:

Requirements:
1) The shell has to be compiled with --enable-gctimer

Tested with python2.6
