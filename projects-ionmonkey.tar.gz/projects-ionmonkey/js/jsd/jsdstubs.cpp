/* -*- Mode: C; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 2 -*- */
/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/* this is all going away... replaced by code in js/jsd/java */

#if 0

#include "_stubs/netscape_jsdebug_Script.c"
#include "_stubs/netscape_jsdebug_DebugController.c"
#include "_stubs/netscape_jsdebug_JSThreadState.c"
#include "_stubs/netscape_jsdebug_JSStackFrameInfo.c"
#include "_stubs/netscape_jsdebug_JSPC.c"
#include "_stubs/netscape_jsdebug_JSSourceTextProvider.c"

#endif
